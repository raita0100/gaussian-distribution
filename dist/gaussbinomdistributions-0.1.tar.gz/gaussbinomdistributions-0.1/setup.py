from setuptools import setup

setup(name='gaussbinomdistributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['gaussbinomdistributions'],
      zip_safe=False)
